import mongoose from "mongoose";
import fetch from "node-fetch"; // Make sure you have node-fetch installed

const MAX_RETRIES = 10;

const failedHookSchema = new mongoose.Schema({
  event: Object,
  error: String,
  retries: { type: Number, default: 0 },
  timestamp: { type: Date, default: Date.now },
});

const FailedHook = mongoose.model("FailedHook", failedHookSchema);

export const handler = async () => {
  let connection;

  try {
    // Connect to MongoDB
    connection = await mongoose.connect(
      "mongodb+srv://lambda-fn:WppBDAyE8D4Or0i6@main-cluster.zvzhccm.mongodb.net/scriptopia?retryWrites=true&w=majority&appName=main-cluster",
      { useNewUrlParser: true, useUnifiedTopology: true }
    );
    console.log("Connected to MongoDB");

    // Fetch failed events
    const failedEvents = await FailedHook.find();

    // Process events in parallel
    const processingPromises = failedEvents.map(async (event) => {
      try {
        const response = await fetch(
          "https://webhook.site/c0bf4ab7-f0d7-48c9-8876-57566b37ba50",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(event),
          }
        );

        if (response.ok) {
          console.log("Event sent to webhook.site");
          await FailedHook.deleteOne({ _id: event._id });
        } else {
          throw new Error(`Failed to send event, status: ${response.status}`);
        }
      } catch (error) {
        console.error(
          `Error sending event to webhook.site for event: ${event._id}`,
          error
        );

        // Retry logic
        await FailedHook.updateOne(
          { _id: event._id },
          { $inc: { retries: 1 } }
        );

        const updatedEvent = await FailedHook.findById(event._id);
        if (updatedEvent.retries >= MAX_RETRIES) {
          console.log(`Max retries reached for event: ${event._id}`);
          await FailedHook.deleteOne({ _id: event._id });
        }
      }
    });

    // Wait for all promises to complete
    await Promise.all(processingPromises);
  } catch (error) {
    console.error("Error in handler: ", error);
  } finally {
    if (connection) {
      await mongoose.disconnect();
      console.log("Disconnected from MongoDB");
    }
  }
};

