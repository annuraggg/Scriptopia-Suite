interface Permission {
  _id?: string;
  name: string;
  description?: string;
}

export default Permission;
