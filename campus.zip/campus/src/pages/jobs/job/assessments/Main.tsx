import { motion } from "framer-motion";
import { Accordion, AccordionItem, Input, Textarea } from "@nextui-org/react";
import { Tabs, Tab } from "@nextui-org/react";

const Main = ({ drive }: { drive: any }) => {
  return <div className="p-10 py-5">d</div>;
};

export default Main;
