const Interviews = () => {
  return <div className="p-10">d</div>;
};

export default Interviews;
