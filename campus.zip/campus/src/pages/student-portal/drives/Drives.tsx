const Drives = () => {
  return <div>in pages/student-portal/drives/Drives.tsx</div>;
};

export default Drives;
