const Dashboard = () => {
  return <div>in pages/student-portal/dashboard/Dashboard.tsx</div>;
};

export default Dashboard;
