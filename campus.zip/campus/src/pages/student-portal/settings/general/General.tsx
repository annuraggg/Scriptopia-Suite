const General = () => {
  return <div>in pages/student-portal/settings/general/General.tsx</div>;
};

export default General;
