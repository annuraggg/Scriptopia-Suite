const Notifications = () => {
  return <div>in pages/student-portal/notifications/Notifications.tsx</div>;
};

export default Notifications;
