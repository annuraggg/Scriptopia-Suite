//import { 
//  Card,
//  CardHeader,
//  CardBody,
//  CardFooter,
//  Button,
//  Input,
//  Select,
//} from "@nextui-org/react"
const Publications = () => {
  return (
    <div>Publications</div>
  )
}

export default Publications