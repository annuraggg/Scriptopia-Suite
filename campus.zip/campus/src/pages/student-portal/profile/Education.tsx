
const Education = () => {
  return (
    <div>Education</div>
  )
}

export default Education