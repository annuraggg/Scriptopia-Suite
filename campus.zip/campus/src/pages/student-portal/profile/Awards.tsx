
const Awards = () => {
  return (
    <div>Awards</div>
  )
}

export default Awards