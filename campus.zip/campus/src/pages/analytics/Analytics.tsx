const Analytics = () => {
  return <div>Analytics</div>;
};

export default Analytics;
